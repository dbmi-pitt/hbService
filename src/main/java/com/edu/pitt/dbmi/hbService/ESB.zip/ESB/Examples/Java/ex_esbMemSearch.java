/*----------------------------------------------------------------------*/
/*  Copyright (c) 2004 by Initiate Systems, Inc. (INITIATE)             */
/*                         All Rights Reserved.                         */
/*         THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF INITIATE.     */
/*         The copyright notice above does not evidence any             */
/*         actual or intended publication of such source code.          */
/*----------------------------------------------------------------------*/
package initiatews.example;

/**
 * <p>Title: Web Service Client</p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Initiate Systems, Inc.</p>
 * @author not attributable
 * @version 1.0
 */

import com.initiate.bean.*;
import edu.upmc.www.esdm.empi.service.*;
import esdm.edu.upmc.www.empi.service.*;

import java.beans.*;
import java.lang.reflect.Method;
import java.text.SimpleDateFormat;
import java.util.Calendar;


/**
 *  This example illustrates the use of the searchMember operation.
 *  This operation searches for member information based on the
 *  attributes we provide.
 */
public class ex_esbMemSearch
{

    /**
     * This method searches and retrives member data based
     * on the segment code filter.
     *
     * @return Member[] the Member array
     */
    public Member[] execute()
    {
        WSExport1_IEMPIServiceHttpService service;
        IEMPIService    port = null;
        try
        {
            // Create an IdentityHubServiceLocator object
            // The IdentityHubServiceLocator is the starting point for
            // accessing the services.
            service = new WSExport1_IEMPIServiceHttpServiceLocator();

            // Create an IdentityHubPort object.
            // The IdentityHubPort provides support for the
            // dynamic invocation of a service endpoint.
            port = service.getWSExport1_IEMPIServiceHttpPort();
        }
        catch(Exception e)
        {
            System.err.println(e.getMessage());
            e.printStackTrace();
            System.exit(0);
        }

        // Create request object using which we pass input
        // parameters to the operation.
        MemberSearchRequest request = new MemberSearchRequest();

        // Create Member object for the Operation.
        Member member   = new Member();

        // Create an empty memHead, always need a MemHead
        MemHeadWs memHead = new MemHeadWs();
        // Set the MemberHeadWs object to the member.
        member.setMemHead(memHead);

        // The search is performed based on the member's
        // legal name and birth date.
        // Construct/initialize a memName record and set
        // it to the member.
        MemNameWs[] memName = new MemNameWs[1];
        memName[0] = new MemNameWs();
        memName[0].setAttrCode("LGLNAME");
        memName[0].setOnmFirst("Mike");
        memName[0].setOnmLast("Detest");
        member.setMemName(memName);

        // Construct/initialize a memDate record and
        // set it to the member.
        MemDateWs[] memDate = new MemDateWs[1];
        memDate[0] = new MemDateWs();
        memDate[0].setAttrCode("BIRTHDT");
        memDate[0].setDateVal("2001-06-20");
        member.setMemDate(memDate);

	// Set the Gender 
	MemAttrWs[] memAttr = new MemAttrWs[1];
	memAttr[0] = new MemAttrWs();
	memAttr[0].setAttrCode("SEX");
	memAttr[0].setAttrVal("M");
	member.setMemAttr(memAttr);

        MemIdentWs[] memIdent = new MemIdentWs[3];
        memIdent[0] = new MemIdentWs();
        memIdent[0].setAttrCode("SSN");
        memIdent[0].setIdNumber("111223333");
        memIdent[0].setIdIssuer("SSA");
        member.setMemIdent(memIdent);

        memIdent[1] = new MemIdentWs();
        memIdent[1].setAttrCode("EMPIID");
        memIdent[1].setIdNumber("1111");
        memIdent[1].setIdIssuer("empiid");
        member.setMemIdent(memIdent);

        memIdent[2] = new MemIdentWs();
        memIdent[2].setAttrCode("MPACMRN");
        memIdent[2].setIdNumber("2222");
        memIdent[2].setIdIssuer("mpacmrn");
        member.setMemIdent(memIdent);

        // Set the Member object to the request.
        request.setMember(member);

        // Set the username & password for the operation
        request.setUserName("yourUserName");
        request.setUserPassword("yourPassword");

        // Set entity type as Identity (id).
        // Entity types are listed in mpi_enttype table.
        request.setEntType("id"); //hh or id.

        // Set a segment code filter to limit output
        // to specific segments.
        request.setSegCodeFilter("MEMHEAD,MEMATTRALL");

        // Set the member type as PERSON.
        // Member types are listed in mpi_memtype table.
        request.setMemType("PERSON");

        // Specify that if any member of an Entity meets
        // the requirements of the operation, all related members
        // in the Entity should also be retrieved.
        request.setGetType("ASENTITY");

        //Sets the sort order based on MemHead values
        request.setKeySortOrder("-getMatchScore,-getEntRecno");

	// Set the composite view
	request.setCvwName("EMCA"); 

        // Set the minimum score to limit output.
        request.setMinScore(new Short((short) 0));

	// Set the max rows to be returned
	request.setMaxRows(10);

        try
        {
            // Perform the searchMember operation.
            return port.searchMember(request);
        }
        catch(Exception e)
        {
            System.err.println(e.getMessage());
            e.printStackTrace();
            System.exit(0);
        }

        return null;
    }


    /**
     * This method prints an array of objects representing the
     * Initiate Web Services types using the dumpObject method.
     *
     * @param obj the object array
     */
    public void dumpArray(Object[] obj)
    {
        if (obj == null)
        {
            return;
        }

        // Iterate through the object array and print each object.
        for (int k = 0; k < obj.length; k++)
        {
            dumpObject(obj[k]);
        }
    }

    /**
     * This method prints the data contained in an object
     * representing a Initiate Web Services type.
     *
     * @param obj the object
     */
    public void dumpObject(Object obj)
    {
        try
        {
            // Get the list of methods of the class of obj
            Class objClass = obj.getClass();
            System.out.print(objClass.getName().substring(18) + ".");
            Method[] allMethods = objClass.getMethods();

            // Iterate through the methods of the class and invoke
            // the methods which retrieve segment information
            for (int z = 0; z < allMethods.length; z++)
            {
                 // Get the name, return type of the method.
                String methodName = allMethods[z].getName();
                String retName = allMethods[z].getReturnType().getName();

                // Identify the methods which retrieve segment
                // information
                if ((methodName.startsWith("get"))
                        && (!methodName.equals("getSerializer"))
                        && (!methodName.equals("getDeserializer"))
                        && (!methodName.equals("getClass"))
                        && (!methodName.endsWith("timeAsDayString"))
                        && (!methodName.equals("getTypeDesc")))
                {
                    // Get an instance of the method from the
                    // class of obj.
                    Class[] paramClassArray = { };
                    Method getter =
                            objClass.getMethod(methodName, paramClassArray);
                    Object[] paramArray = {};

                    // Invoke the getter method
                    Object returnObject = getter.invoke(obj, paramArray);

                    // If the return type of the method is date/time,
                    // print it in the format specified using
                    // SimpleDateFormat.
                    if (retName.equals("java.util.Calendar"))
                    {
                        SimpleDateFormat sdf =
                                new SimpleDateFormat("MM-dd-yy hh:mm:ss.SS");
                        String sDateStr =
                                sdf.format(((Calendar)returnObject).getTime());
                        System.out.print("" + methodName + ":");
                        System.out.print(sDateStr + "  ");
                    }
                    else
                    {
                        // Print the method name along with the values
                        // returned by executing it, if the return
                        // type is not date
                        System.out.print("" + methodName + ":");
                        System.out.print(returnObject + "  ");
                    }
                }
            }
        }
        catch (Exception ex)
        {
            System.err.println(ex.getMessage());
        }

        System.out.println("");
    }

    /*
     * Performs a Member search using MemName and MemDate rows.
     * This example does not take any parameters.
     */
    public static void main(String args[])
    {

        ex_esbMemSearch memSearch = new ex_esbMemSearch();

        Member[] members = null;
        try
        {
            // Perform the searchMember operation.
            members = memSearch.execute();
        }
        catch(Exception e)
        {
            System.err.println(e.getMessage());
            e.printStackTrace();
        }

        // Print the member information
        for (int i = 0; i < members.length; i++)
        {
            System.out.println("*** Member Start ****");

            // Get the member header information and
            // print it.
            MemHeadWs memHeadWs = members[i].getMemHead();
            memSearch.dumpObject(memHeadWs);

            // Get the member's name and print it.
            MemNameWs[] memNameWs = members[i].getMemName();
            memSearch.dumpArray(memNameWs);

            // Get the member's attributes  and print it.
            MemAttrWs[] memAttrWs = members[i].getMemAttr();
            memSearch.dumpArray(memAttrWs);

            // Get the member's birthdate information and print it.
            MemDateWs[] memDateWs = members[i].getMemDate();
            memSearch.dumpArray(memDateWs);

            // Get the member's phone number information and print it.
            MemPhoneWs[] memPhoneWs = members[i].getMemPhone();
            memSearch.dumpArray(memPhoneWs);

            // Get the member's address information  and print it.
            MemAddrWs[] memAddrWs = members[i].getMemAddr();
            memSearch.dumpArray(memAddrWs);

            // Get the member's SSN and print it.
            MemIdentWs[] memIdentWs = members[i].getMemIdent();
            memSearch.dumpArray(memIdentWs);

            // Get the member's tasks and print it.
            MemXtskWs[] memXtskWs = members[i].getMemXtsk();
            memSearch.dumpArray(memXtskWs);

	    EntXtskWs[] entXtskWs = members[i].getEntXtsk();
            memSearch.dumpArray(entXtskWs);


            System.out.println("*** Member End   ****");
        }

        System.exit(0);
    }



}
