/*----------------------------------------------------------------------*/
/*  Copyright (c) 2004 by Initiate Systems, Inc. (INITIATE)             */
/*                         All Rights Reserved.                         */
/*         THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF INITIATE.     */
/*         The copyright notice above does not evidence any             */
/*         actual or intended publication of such source code.          */
/*----------------------------------------------------------------------*/

package initiatews.example;

/**
 * <p>Title: Web Service Client</p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Initiate Systems, Inc.</p>
 * @author not attributable
 * @version 1.0
 */

import com.initiate.bean.*;
import edu.upmc.www.esdm.empi.service.*;
import esdm.edu.upmc.www.empi.service.*;

import java.beans.*;
import java.lang.reflect.Method;
import java.text.SimpleDateFormat;
import java.util.Calendar;

/*
 * This example illustrates the use of the getMember operation which
 * can be used to get member information.
 */
public class ex_esbMemGetProvider
{
    String m_sSegCodeFilter = "MEMHEAD,MEMATTRALL";

    /**
     * This method gets the Member data from the Member table
     * based on the segment codes, source code and member Id.
     *
     * @param sSegCodeFilter segment code filter
     * @param sSrcCode source code
     * @param sMemIdnum member Id
     *
     * @param Member[] member information
     *
     *  Used by other examples to verify they worked properly.
     *
     */
    public Member[] execute(String sDomain,
                            String sSrcCode,
                            String sMemIdnum)
    {
        //get service and port to use
        WSExport1_IEMPIServiceHttpService service;
        IEMPIService    port = null;
        try
        {
            // Create an IdentityHubServiceLocator object.
            // The IdentityHubServiceLocator is the starting point
            // for accessing the services.
            service = new WSExport1_IEMPIServiceHttpServiceLocator(sDomain);

            // Create an IdentityHubPort object.
            // The IdentityHubPort provides support for the
            // dynamic invocation of a service endpoint.
            port    = service.getWSExport1_IEMPIServiceHttpPort();

            // Create a request object using which we pass input
            // parameters to the operation.
            MemberGetRequest request = new MemberGetRequest();

            // Setup the SrcCode:MemIdnum key used for the get
            request.setSrcCode(sSrcCode);
            request.setMemIdnum(sMemIdnum);

            // Set username & password to authenticate as
            request.setUserName("YourUserName");
            request.setUserPassword("YourPassword");
         
            // Set entity type as Identity (id).
            // Entity types are listed in mpi_enttype table.
            request.setEntType("dr"); 

            // Setup Member Type of Member 
            // Member types are listed in mpi_memtype table.
            request.setMemType("PROVIDER");

            // Setup Get Type ASENTITY to get all
            // linked members with this member
            request.setGetType("ASENTITY");
	    
	    // Set the composite view
	    request.setCvwName("EMCA"); 	    

            // Sets the sort order of the Members
            // You can specify a sort based on the MemHead values
	    request.setKeySortOrder("-getMatchScore,-getEntRecno");

            // Perform the getMember operation.
            Member[] members = port.getMember(request);
            return members;

        }
        catch(Exception e)
        {
            System.err.println(e.getMessage());
            e.printStackTrace();

        }

        return null;
    }


    /**
     * This method prints an array of objects representing the
     * Initiate Web Services types using the dumpObject method.
     *
     * @param obj the object array
     */
    public void dumpArray(Object[] obj)
    {
        if (obj == null)
        {
            return;
        }

        // Iterate through the object array and print each object.
        for (int k = 0; k < obj.length; k++)
        {
            dumpObject(obj[k]);
        }
    }

    /**
     * This method prints the data contained in an object
     * representing a Initiate Web Services type.
     *
     * @param obj the object
     */
    public void dumpObject(Object obj)
    {
        try
        {
            // Get the list of methods of the class of obj
            Class objClass = obj.getClass();
            System.out.println("\n" + objClass.getName().substring(18));
	    System.out.println("------------------");
            Method[] allMethods = objClass.getMethods();

            // Iterate through the methods of the class and invoke
            // the methods which retrieve segment information
            for (int z = 0; z < allMethods.length; z++)
            {
                 // Get the name, return type of the method.
                String methodName = allMethods[z].getName();
                String retName = allMethods[z].getReturnType().getName();

                // Identify the methods which retrieve segment
                // information
                if ((methodName.startsWith("get"))
                        && (!methodName.equals("getSerializer"))
                        && (!methodName.equals("getDeserializer"))
                        && (!methodName.equals("getClass"))
                        && (!methodName.endsWith("timeAsDayString"))
                        && (!methodName.equals("getTypeDesc")))
                {
                    // Get an instance of the method from the
                    // class of obj.
                    Class[] paramClassArray = { };
                    Method getter =
                            objClass.getMethod(methodName, paramClassArray);
                    Object[] paramArray = {};

                    // Invoke the getter method
                    Object returnObject = getter.invoke(obj, paramArray);

                    // If the return type of the method is date/time,
                    // print it in the format specified using
                    // SimpleDateFormat.
                    if (retName.equals("java.util.Calendar"))
                    {
                        SimpleDateFormat sdf =
                                new SimpleDateFormat("MM-dd-yy hh:mm:ss.SS");
                        String sDateStr =
                                sdf.format(((Calendar)returnObject).getTime());
                        System.out.print(methodName + ": ");
                        System.out.print(sDateStr + "   ");
                    }
                    else
                    {
                        // Print the method name along with the values
                        // returned by executing it, if the return
                        // type is not date
                        System.out.print(methodName + ": ");
                        System.out.print(returnObject + "   ");
                    }
                } 
            }
        }
        catch (Exception ex)
        {
            System.err.println(ex.getMessage());
        }

        System.out.println("");
    }


    /**
     * This method is the entry point for executing this class and
     * calls the doGetMember method.
     *
     */
    public static void main(String args[])
    {
        Member[] members;
        ex_esbMemGetProvider memGet = new ex_esbMemGetProvider();

        // Get member information.
        // If the user passes insufficient number of arguments then
        // ArrayIndexOutOfBoundsException is thrown
        try
        {
            members = memGet.execute(args[0],  // domain
                                     args[1],  // srcCode
                                     args[2]); // memIdnum
        }
        catch(ArrayIndexOutOfBoundsException e)
        {
            // If no arguments are passed then take default values.
            members = memGet.execute(null, null, null);
        }

	int j=0;
        // Print the member information
        for (int i = 0; i < members.length; i++)
        {

	    // *** NOTE ***
	    // Providers only have data on the MPI_MEMHEAD, MPI_MEMNAME, MPI_MEMATTR, MPI_MEMIDENT, MPI_MEMDATE segments.

	    j = i + 1;
	    System.out.println("========================");
            System.out.println("= Member Record " + j + " of " + members.length + " =");
	    System.out.println("========================");

            // Get the member header information and
            // print it.
            MemHeadWs memHeadWs = members[i].getMemHead();
            memGet.dumpObject(memHeadWs);

            // Get the member's name and print it.
            MemNameWs[] memNameWs = members[i].getMemName();
            memGet.dumpArray(memNameWs);

            // Get the member's attributes  and print it.
            MemAttrWs[] memAttrWs = members[i].getMemAttr();
            memGet.dumpArray(memAttrWs);

            // Get the member's SSN and print it.
            MemIdentWs[] memIdentWs = members[i].getMemIdent();
            memGet.dumpArray(memIdentWs);

            // Get the member's birthdate information and print it.
            MemDateWs[] memDateWs = members[i].getMemDate();
            memGet.dumpArray(memDateWs);

	    System.out.println("\n");
        }

	System.out.println("---------------------------------\n");
	System.out.println("TOTAL MEMBERS RETURNED: " + members.length);

        System.exit(0);
    }
}
