package edu.pitt.dbmi.EmpiUtil;

import java.net.MalformedURLException;
import java.net.URL;
import javax.xml.namespace.QName;
import javax.xml.ws.WebServiceException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.initiate.bean.IdentityHubPort;
import com.initiate.bean.IdentityHubService;

/*
import org.apache.cxf.endpoint.Client;
import org.apache.cxf.frontend.ClientProxy;
import org.apache.cxf.interceptor.LoggingInInterceptor;
import org.apache.cxf.interceptor.LoggingOutInterceptor;
*/

public class EmpiService {
	@Autowired
	private static final Logger log = LoggerFactory.getLogger(EmpiService.class);
	static final Short defaultMinScore = 0;
	static final Integer defaultMaxRows = 25;
	
	private IdentityHubService identityHubService;
    private IdentityHubPort identityHubPort;
	private URL wsdlURL;
	private static final QName DEV_SERVICE_NAME = new QName("urn:bean.initiate.com", "IdentityHubService");
	private String username;
	private String password;
	private String viewerUrl;
	private String lastErrCode;
	private String lastErrMsg;
	private Short minScore;
	private Integer maxRows;
	
	public EmpiService() {
		log.info("Creating EMPI Service!");
		minScore = defaultMinScore;  	// Setup default values
		maxRows = defaultMaxRows;	// Setup default values
	}
	

	// Create the service client with its configured wsdlurl
	public boolean initialze() {
		if ((this.identityHubService == null) || (this.identityHubPort == null)) {
			try {
				this.setLastErrCode("");
				this.setLastErrMsg("");
				this.identityHubService = new IdentityHubService(this.wsdlURL,DEV_SERVICE_NAME);
				log.info(this.identityHubService.getServiceName().toString());
				log.info(this.identityHubService.getWSDLDocumentLocation().toString());
				this.identityHubPort = this.identityHubService.getIdentityHub();
/*
 * Replaced by configuration in src/main/resources/cxf.xml
 * 
 * 				Client client = ClientProxy.getClient(this.identityHubPort);
 *				client.getInInterceptors().add(new LoggingInInterceptor());
 *				client.getOutInterceptors().add(new LoggingOutInterceptor());
 */
			} 
			catch (WebServiceException wse) {
				StringBuilder errMsg = new StringBuilder();
				errMsg.append(wse.getMessage());
				log.info(wse.getMessage());
				Throwable cause = wse.getCause();
				while (cause != null) {
					errMsg.append(cause.getMessage() + " # ");
					log.info(cause.getMessage());
					cause = cause.getCause();
				}
				this.setLastErrCode("INITFAILED");
				this.setLastErrMsg(errMsg.toString());
				if (log.isDebugEnabled()) {
					wse.printStackTrace();
				}
				this.identityHubService = null;
				this.identityHubPort = null;
				return false;
			}
			catch (Exception e) {
				e.printStackTrace();
				this.identityHubService = null;
				this.identityHubPort = null;
				return false;
			}
		}
        return true;
	}
	
	// Call this function to reset the service and port if there is a communication error
	public void reset() {
		this.identityHubService = null;
		this.identityHubPort = null;
		this.setLastErrCode("");
		this.setLastErrMsg("");
	}

	public void setService(IdentityHubService identityHubService) {
		this.identityHubService = identityHubService;
	}

	public IdentityHubService getService() {
		return identityHubService;
	}

	public String getQNameStr() {
		return DEV_SERVICE_NAME.toString();
	}
	
	public void setPort(IdentityHubPort identityHubPort) {
		this.identityHubPort = identityHubPort;
	}

	public IdentityHubPort getPort() {
		return identityHubPort;
	}

	public void setWsdl(String wsdl) {
    	URL wsdlURL = null;
		try {
			wsdlURL = new URL(wsdl);
		} catch (MalformedURLException e) {
			e.printStackTrace();
		}		
		this.wsdlURL = wsdlURL;
	}
	
	public void setWsdlURL(URL wsdlURL) {
		this.wsdlURL = wsdlURL;
	}

	public URL getWsdlURL() {
		return wsdlURL;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getUsername() {
		return username;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getPassword() {
		return password;
	}

	public Short getMinScore() {
		return minScore;
	}

	public void setMinScore(Short minScore) {
		this.minScore = minScore;
	}

	public Integer getMaxRows() {
		return maxRows;
	}

	public void setMaxRows(Integer maxRows) {
		this.maxRows = maxRows;
	}


	public void setViewerUrl(String viewerUrl) {
		this.viewerUrl = viewerUrl;
	}

	public String getViewerUrl() {
		return viewerUrl;
	}

	public void setLastErrCode(String lastErrCode) {
		this.lastErrCode = lastErrCode;
	}

	public String getLastErrCode() {
		return lastErrCode;
	}

	public void setLastErrMsg(String lastErrMsg) {
		this.lastErrMsg = lastErrMsg;
	}

	public String getLastErrMsg() {
		return lastErrMsg;
	}


	public Boolean isInitialized() {
		if ((this.identityHubService != null) &&
			(this.identityHubPort != null)) {
			return true;
		}
		return false;
	}


	public String getHost() {
		StringBuilder host = new StringBuilder();
		if (this.wsdlURL != null) {
			host.append(wsdlURL.getProtocol());
			host.append("://");
			host.append(wsdlURL.getHost());
			host.append(wsdlURL.getPath());
		}
		return host.toString();
	}

}
