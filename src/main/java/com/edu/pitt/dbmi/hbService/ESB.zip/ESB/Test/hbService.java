import java.util.Scanner;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.Arrays;
import java.util.ArrayList;
import java.util.Date;
import java.text.SimpleDateFormat;

import javax.xml.ws.WebServiceException;
import javax.xml.ws.soap.SOAPFaultException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.initiate.bean.*;

import edu.pitt.dbmi.scheduler.web.util.DateFormatUtil;
import edu.pitt.dbmi.scheduler.web.util.SearchResult;

// // ESB imports
// import com.initiate.bean.*;
// import edu.upmc.www.esdm.empi.service.*;
// import esdm.edu.upmc.www.empi.service.*;
// import java.beans.*;
// import java.lang.reflect.Method;
// import java.util.Calendar;

public class hbService
{
	@Autowired
	private static final Logger log = LoggerFactory.getLogger(EmpiUtil.class);
	private static final Logger logAudit = LoggerFactory.getLogger("EmpiAudit");

	private static List<Member> processMemberRequest(String[] auditStrings, EmpiService svc, IxnBaseRequest request) {
		String[] auditMessage = new String(4);
		auditMessage[0] = auditStrings[0];
		auditMessage[1] = auditStrings[1];
		auditMessage[2] = request.getArgs();

		try {
	        // Set the username & password for the operation
	        request.setUserName(svc.getUsername());   // YOUR USERNAME HERE
	        request.setUserPassword(svc.getPassword());  // YOUR PASSWORD HERE
	        
	        ArrayOfMember memberArr = null;
			if (request instanceof MemberSearchRequest) {
				MemberSearchRequest searchRequest = (MemberSearchRequest) request;
				// Has minScore been changed from the default value?
				if (searchRequest.getMinScore() != svc.getMinScore()) {
					searchRequest.setMinScore(svc.getMinScore());
				}
				// Has maxRows been changed from the default value?
				if (searchRequest.getMaxRows() != svc.getMaxRows()) {
					searchRequest.setMaxRows(svc.getMaxRows());
				}
				memberArr = svc.getPort().searchMember(searchRequest);
			} else if (request instanceof MemberGetRequest) {
				memberArr = svc.getPort().getMember((MemberGetRequest) request);
			} else {
				return null;
			}
			List<Member> members = memberArr.getItem();
			if (members.isEmpty()) {
				log.info("No Members found!");
			} else {
				log.info("Found " + members.size() + " Members!");
			}
			auditMessage[3] = Integer.toString(members.size());
			logAudit.info("{}; {}; {}; {}", auditMessage);
	        return members;
		} catch (SOAPFaultException se) {
			// Exception is received when there is a search/get with no result
			// an error code of ENOREC will be received.  See API Usage Guide
			// in Welcome Packet for details on message
			String message = se.getMessage();
			// Parse message to make sure it is from Initiate
			String[] messageParts = message.split(": ");
			if ((messageParts[0].equals("MemberException")) && 
				(messageParts[1].equals("com.initiate.bean.MemberException"))) {
				// Third field will be code (with extra [0] on it)
				String errorCode = messageParts[3];
				// Fourth field is detailed message, got array out of range error once, so add condition
				String errorMsg;
				if(messageParts.length > 4)
					errorMsg = messageParts[4];
				else
					errorMsg = se.getMessage();
				if (errorCode.contains("ENOREC")) {
					svc.setLastErrCode("ENOREC");
					svc.setLastErrMsg(errorMsg);
					log.error("No records found:" + errorCode + ":" + errorMsg);
				} else {
					svc.setLastErrCode(errorCode);
					svc.setLastErrMsg(errorMsg);
					log.error("Unexpected error: " + errorCode + ":" + errorMsg);
				}
			} else {
				log.error(se.getMessage());
				se.printStackTrace();				
			}
			auditMessage[3] = se.getMessage();
			logAudit.info("{}; {}; {}; {}", auditMessage);
	        
		} catch (WebServiceException we) {
			log.error(we.getMessage());
			auditMessage[3] = we.getMessage();
			logAudit.info("{}; {}; {}; {}", auditMessage);
	        we.printStackTrace();			
		} catch (Exception e) {
			log.error(e.getMessage());
			auditMessage[3] = e.getMessage();
			logAudit.info("{}; {}; {}; {}", auditMessage);
	        e.printStackTrace();
		}
		return null;
	}

	public static ArrayOfDictionary processNetInfoRequest(String[] auditStrings, EmpiService svc, NetInfoGetRequest request) {
		try {
	        // Set the username & password for the operation
	        request.setUserName(svc.getUsername());   // YOUR USERNAME HERE
	        request.setUserPassword(svc.getPassword());  // YOUR PASSWORD HERE
        	ArrayOfDictionary netInfoResponse = svc.getPort().getNetworkInfo((NetInfoGetRequest)request);
			return netInfoResponse;
		} catch (WebServiceException we) {
			log.error(we.getMessage());
			we.printStackTrace();			
		} catch (Exception e) {
			log.error(e.getMessage());
			e.printStackTrace();
		}
		return null;
	}

	public static List<Member> searchForMembers(String[] auditStrings, EmpiService svc, MemberSearchRequest request) {
    	return processMemberRequest(auditStrings, svc, request);
    }
    

    public static List<Member> getMembers(String[] auditStrings, EmpiService svc, MemberGetRequest request) {
    	return processMemberRequest(auditStrings, svc, request);
    }

    public static String formatEmpiMember(EmpiMember empiMember) {
    	StringBuilder fmtMember = new StringBuilder();
		// Get the Match Score from the Header
		fmtMember.append(String.format("%7d %4.1f ",empiMember.getEntRecNo(), empiMember.getMatchCalc()));
		int numSources = empiMember.getNumSources();
		if (numSources > 0) {
			fmtMember.append(String.format("%-17s ",empiMember.getSource(0)));
		}
		if (numSources > 1) {
			fmtMember.append(String.format("%-17s ",empiMember.getSource(1)));
		} else {
			fmtMember.append(String.format("%-17s ", ""));
		}
		if (numSources > 2) {
			fmtMember.append(String.format("MORE THAN 2 SOURCES %-17s ",empiMember.getSource(2)));
		}
		// Get the Member Name from the memNameArr (take the first one)
		// fmtMember.append(empiMember.getNameCode() + " ");
		fmtMember.append(String.format("%-22s ", empiMember.getOnmLast() + ", " + 
				empiMember.getOnmFirst() + " " + empiMember.getOnmMiddle()));
		fmtMember.append(String.format("%-11s ", empiMember.getFmtSsn()));
		fmtMember.append(empiMember.getBirthDt() + " ");
		fmtMember.append(String.format("%-8s ", empiMember.getFmtSex()));
		fmtMember.append(String.format("%-15s ", "EMPIID:" + empiMember.getEmpiId()));
		fmtMember.append(empiMember.getStLine1() + " " + empiMember.getCity() + "," + empiMember.getState() + " " + empiMember.getZipCode() + " ");
		fmtMember.append(empiMember.getPhCode1() + ":" + empiMember.getPhNumber1() + " ");
		if ((empiMember.getPhCode2() != null) && (!empiMember.getPhCode2().isEmpty())) {
			fmtMember.append(empiMember.getPhCode2() + ":" + empiMember.getPhNumber2() + " ");        					
		}
		if (empiMember.getEpicMrn() != null) {
			fmtMember.append("EPICMRN:" + empiMember.getEpicMrn() + " ");
		}
		if (empiMember.getMpacMrn() != null) {
			fmtMember.append("MPACMRN:" + empiMember.getMpacMrn() + " ");
		}
		return fmtMember.toString();
    }

    private static MemberSearchRequest getDefaultSearchRequest() {
    	// Create request object using which we pass input
        // parameters to the operation.
        MemberSearchRequest request = new MemberSearchRequest();
        
        // Create Member object for the Operation.
        Member member = new Member();

        // Create an empty memHead, always need a MemHead
        MemHeadWs memHead = new MemHeadWs();
        // Set the MemberHeadWs object to the member.
        member.setMemHead(memHead);

        // Set the Member object to the request.
        request.setMember(member);

        // Set a segment code filter to limit output
        // to specific segments.
        request.setSegCodeFilter("MEMHEAD,MEMADDR,MEMATTR,MEMDATE,MEMIDENT,"
                + "MEMNAME,MEMPHONE,MEMXTSK");

        request.setSrcCodeFilter("EPIC,MEDIPAC");

        // Set entity type as Identity (id).
        // Entity types are listed in mpi_enttype table.
        request.setEntType("id"); //hh or id.

        // Set the member type as PERSON.
        // Member types are listed in mpi_memtype table.
        request.setMemType("PERSON");

        // Specify that if any member of an Entity meets
        // the requirements of the operation, all related members
        // in the Entity should also be retrieved.
        // types: ASMEMBER (default), ASENTITY
        // request.setGetType("ASMEMBER");
        request.setGetType("ASENTITY");
        
        // Set the composite view to entity most current attribute
        request.setCvwName("EMCA");
        
        // Sets the sort order based on MemHead values
 		// request.setKeySortOrder("-getMatchScore,-getSrcCode");
        request.setKeySortOrder("-getMatchScore,-getEntRecno");

        // Set the minimum score to limit output.
        request.setMinScore(Short.valueOf(EmpiService.defaultMinScore));
        request.setMaxRows(Integer.valueOf(EmpiService.defaultMaxRows));

        return request;
    }

    public static NetInfoGetRequest getNetInfoRequest() {
        NetInfoGetRequest netInfoGet = new NetInfoGetRequest();
        netInfoGet.setArgs("Net Info Request");
        return netInfoGet;
    }

    private static MemberGetRequest getDefaultGetRequest() {
    	// Create request object using which we pass input
        // parameters to the operation.
        MemberGetRequest request = new MemberGetRequest();

        // Set a segment code filter to limit output
        // to specific segments.
        request.setSegCodeFilter("MEMHEAD,MEMADDR,MEMATTR,MEMDATE,MEMIDENT,"
                                 + "MEMNAME,MEMPHONE,MEMXTSK");

		// request.setSrcCodeFilter("EPIC,MEDIPAC");
        
        // Set entity type as Identity (id).
        // Entity types are listed in mpi_enttype table.
        request.setEntType("id"); //hh or id.

        // Set the member type as PERSON.
        // Member types are listed in mpi_memtype table.
        request.setMemType("PERSON");

        // Specify that if any member of an Entity meets
        // the requirements of the operation, all related members
        // in the Entity should also be retrieved.
        // types: ASMEMBER (default), ASENTITY
        request.setGetType("ASENTITY");
        // request.setGetType("ASMEMBER");
        
        // Set the composite view to entity most current attribute
        request.setCvwName("EMCA");
        
        //Sets the sort order based on MemHead values
//        request.setKeySortOrder("-getMatchScore,-getSrcCode");
        request.setKeySortOrder("-getMatchScore,-getEntRecno");

        return request;
    }

    public static MemberSearchRequest searchByNameRequest(String lname, String fname) {
    	MemberSearchRequest request = getDefaultSearchRequest();
    	
    	Member member = request.getMember();
    	
    	// The search is performed based on the member's
        // legal name and birth date.
        // Construct/initialize a memName record and set
        // it to the member.
        ArrayOfMemNameWs memNameArr = new ArrayOfMemNameWs();
        MemNameWs memName = new MemNameWs();
        memName.setAttrCode("LGLNAME");
        memName.setOnmFirst(fname.toUpperCase());
        log.info(memName.getOnmFirst());
        memName.setOnmLast(lname.toUpperCase());
        log.info(memName.getOnmLast());
        memNameArr.getItem().add(memName);
        //log.trace("Search by last name {}, first name {}, ", memName.getOnmLast(), memName.getOnmFirst());
        member.setMemName(memNameArr);

        // Set the Member object to the request.
        request.setMember(member);
        request.setArgs("Last Name: " + lname + ", First Name: " + fname);

        return request;
    }

    public static MemberSearchRequest searchByNameBirthDtRequest(String lname, String fname, Date birthDate) {
    	MemberSearchRequest request = searchByNameRequest(lname, fname);
    	
    	Member member = request.getMember();
    	
    	//
    	// Construct/initialize a memDate record and
    	// set it to the member.
    	
    	ArrayOfMemDateWs memDateArr = new ArrayOfMemDateWs();
    	MemDateWs memDate = new MemDateWs();
    	memDate.setAttrCode("BIRTHDT");
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
        String fmtDate = format.format(birthDate);
    	memDate.setDateVal(fmtDate);
    	log.info(memDate.getDateVal());
    	memDateArr.getItem().add(memDate);
    	
    	member.setMemDate(memDateArr);

        // Set/Update the Member object to the request.
        request.setMember(member);
        request.setArgs("Last Name: " + lname + ", First Name: " + fname + ", Birth Date: " + DateFormatUtil.simpleDateFormat(birthDate));

        return request;
    }

    public static MemberGetRequest getByMedipacIDRequest(String memIdNum) {
    	MemberGetRequest request = getDefaultGetRequest();
    	  	
    	// 
    	// set request to the MEDIPAC MRN.
        // Setup the SrcCode:MemIdnum key used for the get
        request.setSrcCode("MEDIPAC");
        request.setMemIdnum(memIdNum);
        log.info("MEDIPAC:" + request.getMemIdnum()); 
        request.setArgs("Medipac ID: " + memIdNum);
        return request;
    }

    public static MemberGetRequest getByEpicMRNRequest(String memIdNum) {
    	MemberGetRequest request = getDefaultGetRequest();
    	  	
    	// set request to the EPIC MRN.
        // Setup the SrcCode:MemIdnum key used for the get
        request.setSrcCode("EPIC");
        request.setMemIdnum(memIdNum);
        log.info("EPIC:" + request.getMemIdnum()); 
        request.setArgs("Epic MRN: " + memIdNum);
        return request;
    }

	public static void generateIds()
	{
		// Read patient demographics, group by name, DOB.
		try 
		{
			ArrayList<String> patientList = readDemographics();
			patientList.remove(0); // remove header
			int patientSize = patientList.size();
			String[] patientDemo;
			String[] patientId = new String[patientSize];
			String[] patientMrn = new String[patientSize];
			String[] patientFull = new String[patientSize];
			String[] patientFname = new String[patientSize];
			String[] patientLname = new String[patientSize];
			String[] patientDob = new String[patientSize];
			String dupName, dupDob;
			int yearToChange;
			int yearSet = 2017;
			int id = 1;
			int dup;
			PatientId[] patientClassArray = new PatientId[patientSize]; // might be less, due to duplicates
			String studyId;
			String mrnId, srcId;

			for(int i = 0; i < patientSize; i++)
			{
				patientDemo = patientList.get(i).split("\\t");
				patientId[i] = patientDemo[0] + patientDemo[1];
				patientMrn[i] = patientDemo[2];
				patientFull[i] = patientDemo[3].replaceAll("\\s+", "").toUpperCase();
				patientFname[i] = patientDemo[5];
				patientLname[i] = patientDemo[4];
				
				// Date parsing is incorrect
				// ex. 02/23/37 parse to 2037-02-23
				// need to handle			
				try {
				Date dobParse = new SimpleDateFormat("MM/dd/yy").parse(patientDemo[9]);
				SimpleDateFormat dobFormat = new SimpleDateFormat("yyyy-MM-dd");
				patientDob[i] = dobFormat.format(dobParse); } catch(Exception e){}	
				yearToChange = Integer.parseInt(patientDob[i].substring(0,4));
				if(yearToChange > yearSet) 
				{
					patientDob[i] = "19" + patientDob[i].substring(2);
					//System.out.println(patientDob[i]); // possibly log in the future
				}

				mrnId = patientMrn[i];
				srcId = patientId[i];
				dupName = patientFull[i];
				dupDob = patientDob[i];
				dup = contains(i, patientFull, patientDob, dupName, dupDob);
				if(dup != i) // found duplicate, dup = index of first record
				{
					System.out.println("Duplicate found: index " + dup);
					if(!(patientClassArray[dup]).getSrcIds().contains(srcId))
						patientClassArray[dup].addSrcId(srcId);
					if(!(patientClassArray[dup]).getMpacIds().contains(mrnId))
						patientClassArray[dup].addMpacId(mrnId);
				}
				else 
				{
					studyId = Integer.toString(id);
					PatientId patientClass = new PatientId(studyId, mrnId, srcId);
					patientClassArray[i] = patientClass;
					id++;
				}
			}
			for(PatientId pid : patientClassArray)
			{
				if(pid != null)
					System.out.println(pid.toString());
			}
		}
		catch(IOException e)
		{
			e.printStackTrace();
		}

	// 	// ESB minimal settings structure for MemSearch
	// 	WSExport1_IEMPIServiceHttpService service;
	// 	IEMPIService    port = null;
	// 	try
 //        {
 //            // Create an IdentityHubServiceLocator object
 //            // The IdentityHubServiceLocator is the starting point for
 //            // accessing the services.
 //            service = new WSExport1_IEMPIServiceHttpServiceLocator();

 //            // Create an IdentityHubPort object.
 //            // The IdentityHubPort provides support for the
 //            // dynamic invocation of a service endpoint.
 //            port = service.getWSExport1_IEMPIServiceHttpPort();
 //        }
 //        catch(Exception e)
 //        {
 //            System.err.println(e.getMessage());
 //            e.printStackTrace();
 //            System.exit(0);
 //        }

 //        // Search each person
 //        for(int i = 0; i < patientSize; i++)
 //        {
 //        	// Create request object using which we pass input
	//         // parameters to the operation.
	//         MemberSearchRequest request = new MemberSearchRequest();

	//         // Create Member object for the Operation.
	//         Member member   = new Member();

	//         // Create an empty memHead, always need a MemHead
	//         MemHeadWs memHead = new MemHeadWs();
	//         // Set the MemberHeadWs object to the member.
	//         member.setMemHead(memHead);

	//         // The search is performed based on the member's
	//         // legal name and birth date.
	//         // Construct/initialize a memName record and set
	//         // it to the member.
	//         MemNameWs[] memName = new MemNameWs[1];
	//         memName[0] = new MemNameWs();
	//         memName[0].setAttrCode("LGLNAME");
	//         memName[0].setOnmFirst(patientFname[i]);
	//         memName[0].setOnmLast(patientLname[i]);
	//         member.setMemName(memName);

	//         // Construct/initialize a memDate record and
	//         // set it to the member.
	//         MemDateWs[] memDate = new MemDateWs[1];
	//         memDate[0] = new MemDateWs();
	//         memDate[0].setAttrCode("BIRTHDT");
	//         memDate[0].setDateVal(patientDob[i]);
	//         member.setMemDate(memDate);

    //		}

			// Create PatientId class
				// Generate Id
				// Store any

	}

	public static void appendIds()
	{
		
	}

	public static void printIds() 
	{


	}

	public static int contains(int length, String[] patientName, String[] patientDob, String name, String dob)
	{
		for(int i = 0; i < length; i++)
		{
			if(patientName[i].equals(name) && patientDob[i].equals(dob))
				return i;
		}
		return length;
	}

	// /**
 //     * This method prints an array of objects representing the
 //     * Initiate Web Services types using the dumpObject method.
 //     *
 //     * @param obj the object array
 //     */
 //    public void dumpArray(Object[] obj)
 //    {
 //        if (obj == null)
 //        {
 //            return;
 //        }

 //        // Iterate through the object array and print each object.
 //        for (int k = 0; k < obj.length; k++)
 //        {
 //            dumpObject(obj[k]);
 //        }
 //    }

	// /**
 //     * This method prints the data contained in an object
 //     * representing a Initiate Web Services type.
 //     *
 //     * @param obj the object
 //     */
	// public void dumpObject(Object obj)
	// {
	// 	try
	// 	{
	// 		// Get the list of methods of the class of obj
	// 		Class objClass = obj.getClass();
	// 		System.out.print(objClass.getName().substring(18) + ".");
	// 		Method[] allMethods = objClass.getMethods();

	// 		// Iterate through the methods of the class and invoke
	// 		// the methods which retrieve segment information
	// 		for(int z = 0; z < allMethods.length; z++)
	// 		{
	// 			// Get the name, return type of the method
	// 			String methodName = allMethods[z].getName();
	// 			String retName = allMethods[z].getReturnType().getName();

	// 			// Identity the methods which retrieve segment information
	// 			if((methodName.startsWith("get"))
	// 			&& (!methodName.equals("getSerializer"))
	// 			&& (!methodName.equals("getDeserializer"))
	// 			&& (!methodName.equals("getClass")) 
	// 			&& (!methodName.equals("timaAsDayString")) 
	// 			&& (!methodName.equals("getTypeDesc")))
	// 			{
	// 				// Get an instance of the method from the class obj
	// 				Class[] paramClassArray = {};
	// 				Method getter = objClass.getMethod(methodName, paramClassArray);
	// 				Object paramArray = {};

	// 				// Invoke the getter method
	// 				Object returnObject = getter.invoke(obj, paramArray);

	// 				// If the return type of the method is date/time,
	// 				// print it in the format specified using SimpleDateFormat
	// 				if (retName.equals("java.util.Calendar"))
	// 				{
	// 					SimpleDateFormat sdf = new SimpleDateFormat("MM-dd-yy hh:mm:ss.SS");
	// 					String sDateStr = sdf.format(((Calendar)returnObject).getTime());
	// 					System.out.print("" + methodName + ":" + sDateStr + "  ");
	// 				}
	// 				else
	// 				{
	// 					// Print the method name along with the values returned by executing it
	// 					System.out.print("" + methodName + ":" + returnObject + "  ");
	// 				}
	// 			}
	// 		}
	// 		catch(Exception e)
	// 		{
	// 			System.err.println(e.getMessage());
	// 		}

	// 	}
	// }

	public static ArrayList<String> readDemographics() throws IOException
	{
		ArrayList<String> patientDemoList = new ArrayList<String>();
		try
		{
			FileReader fr = new FileReader("PATIENT_DEMOGRAPHICS.txt");
			BufferedReader br = new BufferedReader(fr);
			String currentLine;
			
			while((currentLine = br.readLine()) != null)
			{
				patientDemoList.add(currentLine);
			} 
			br.close();
			fr.close();
		}
		catch (IOException e) 
		{
			e.printStackTrace();
		}
		return patientDemoList;
	}

	public static void main(String args[])
	{
		Scanner scan = new Scanner(System.in);
		int sel;
		String menu = "Select run options:\n";
		menu += "1) Generate new study ids\n";
		menu += "2) Append new study ids\n";
		menu += "3) Print study ids\n";
		menu += "4) Exit";
		System.out.println(menu);
		sel = scan.nextInt();

		switch(sel)
		{
			case 1:
				System.out.println("This will drop current study ids and make new ones. Are you sure? (y/n)");
				String ans = scan.next();
				if(ans.equals("y") || ans.equals("Y")) 
					generateIds();
				else
					System.out.println("Exiting...");
			break;
			case 2:
				appendIds();
			break;
			case 3:
				printIds();
			break;
			case 4:
				System.out.println("Exiting...");
			break;
			default:
				System.out.println("Not valid option. Re-run and try again");
			break;
		}
	}
}