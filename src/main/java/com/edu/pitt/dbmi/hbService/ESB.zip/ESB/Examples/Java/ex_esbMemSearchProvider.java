/*----------------------------------------------------------------------*/
/*  Copyright (c) 2004 by Initiate Systems, Inc. (INITIATE)             */
/*                         All Rights Reserved.                         */
/*         THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF INITIATE.     */
/*         The copyright notice above does not evidence any             */
/*         actual or intended publication of such source code.          */
/*----------------------------------------------------------------------*/
package initiatews.example;

/**
 * <p>Title: Web Service Client</p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Initiate Systems, Inc.</p>
 * @author not attributable
 * @version 1.0
 */

import com.initiate.bean.*;
import edu.upmc.www.esdm.empi.service.*;
import esdm.edu.upmc.www.empi.service.*;

import java.beans.*;
import java.lang.reflect.Method;
import java.text.SimpleDateFormat;
import java.util.Calendar;


/**
 *  This example illustrates the use of the searchMember operation.
 *  This operation searches for member information based on the
 *  attributes we provide.
 */
public class ex_esbMemSearchProvider
{

    /**
     * This method searches and retrives member data based
     * on the segment code filter.
     *
     * @return Member[] the Member array
     */
    public Member[] execute(String domain)
    {
        WSExport1_IEMPIServiceHttpService service;
        IEMPIService    port = null;
        try
        {
            // Create an IdentityHubServiceLocator object
            // The IdentityHubServiceLocator is the starting point for
            // accessing the services.
            service = new WSExport1_IEMPIServiceHttpServiceLocator(domain);

            // Create an IdentityHubPort object.
            // The IdentityHubPort provides support for the
            // dynamic invocation of a service endpoint.
            port = service.getWSExport1_IEMPIServiceHttpPort();
        }
        catch(Exception e)
        {
            System.err.println(e.getMessage());
            e.printStackTrace();
            System.exit(0);
        }

        // Create request object using which we pass input
        // parameters to the operation.
        MemberSearchRequest request = new MemberSearchRequest();

        // Create Member object for the Operation.
        Member member   = new Member();

        // Create an empty memHead, always need a MemHead
        MemHeadWs memHead = new MemHeadWs();
        // Set the MemberHeadWs object to the member.
        member.setMemHead(memHead);
	
        // Name search
        MemNameWs[] memName = new MemNameWs[1];
        memName[0] = new MemNameWs();
        memName[0].setAttrCode("PHYS_NAME");
        memName[0].setOnmFirst("ASHER");
	memName[0].setOnmMiddle("A");
        memName[0].setOnmLast("TULSKY");
        member.setMemName(memName);

	// DOB search
        MemDateWs[] memDate = new MemDateWs[1];
        memDate[0] = new MemDateWs();
        memDate[0].setAttrCode("PHYS_DOB");
        memDate[0].setDateVal("1966-05-12");
        member.setMemDate(memDate);
	

	// Note that all of the following are on the MPI_MEMIDENT segment, 
	// so we will only define the MemIdentWS once.
	
        MemIdentWs[] memIdent = new MemIdentWs[5];
	
	// SSN Search
        memIdent[0] = new MemIdentWs();
        memIdent[0].setAttrCode("PHYS_SSN");
        memIdent[0].setIdNumber("564777031");
        memIdent[0].setIdIssuer("SSA");
        member.setMemIdent(memIdent);
	
	
	// NPI Search
        memIdent[1] = new MemIdentWs();
        memIdent[1].setAttrCode("PHYS_NPI_ID");
        memIdent[1].setIdNumber("1215903885");
        memIdent[1].setIdIssuer("NPI_P");
        member.setMemIdent(memIdent);

	
	// License # Search
        memIdent[2] = new MemIdentWs();
        memIdent[2].setAttrCode("PHYS_LIC_NO");
        memIdent[2].setIdNumber("MD062638L");
        memIdent[2].setIdIssuer("UK"); // Default is UK - Unknown
        member.setMemIdent(memIdent);
	
	
	// DEA # Search
        memIdent[3] = new MemIdentWs();
        memIdent[3].setAttrCode("PHYS_DEA");
        memIdent[3].setIdNumber("BT7070799");
        memIdent[3].setIdIssuer("DEA_P");
        member.setMemIdent(memIdent);
	
	
	// Medicaid # Search
        memIdent[4] = new MemIdentWs();
        memIdent[4].setAttrCode("PHYS_MDCD_NO");
        memIdent[4].setIdNumber("0006132170009");
        memIdent[4].setIdIssuer("MDCD_P");
        member.setMemIdent(memIdent);

	// Public ESO ID
        memIdent[4] = new MemIdentWs();
        memIdent[4].setAttrCode("PUBLIC_ESO");
        memIdent[4].setIdNumber("4059868688");
        memIdent[4].setIdIssuer("PUBLIC_ESO");
        member.setMemIdent(memIdent);


	

        // Set the Member object to the request.
        request.setMember(member);

        // Set the username & password for the operation
        request.setUserName("YourUserName");
        request.setUserPassword("YourPassword");

        // Set entity type as Identity (id).
        // Entity types are listed in mpi_enttype table.
        request.setEntType("dr"); 

        // Set a segment code filter to limit output
        // to specific segments.
        request.setSegCodeFilter("MEMHEAD,MEMATTRALL");

        // Set the member type as PERSON.
        // Member types are listed in mpi_memtype table.
        request.setMemType("PROVIDER");

        // Specify that if any member of an Entity meets
        // the requirements of the operation, all related members
        // in the Entity should also be retrieved.
        request.setGetType("ASENTITY");

        //Sets the sort order based on MemHead values
        request.setKeySortOrder("-getMatchScore,-getEntRecno");

	// Set the composite view
	request.setCvwName("EMCA"); 

        // Set the minimum score to limit output.
        request.setMinScore(new Short((short) 0));

	// Set the max rows to be returned
	request.setMaxRows(1);

        try
        {
            // Perform the searchMember operation.
            return port.searchMember(request);
        }
        catch(Exception e)
        {
            System.err.println(e.getMessage());
            e.printStackTrace();
            System.exit(0);
        }

        return null;
    }


    /**
     * This method prints an array of objects representing the
     * Initiate Web Services types using the dumpObject method.
     *
     * @param obj the object array
     */
    public void dumpArray(Object[] obj)
    {
        if (obj == null)
        {
            return;
        }

        // Iterate through the object array and print each object.
        for (int k = 0; k < obj.length; k++)
        {
            dumpObject(obj[k]);
        }
    }




    /**
     * This method prints the data contained in an object
     * representing a Initiate Web Services type.
     *
     * @param obj the object
     */
    public void dumpObject(Object obj)
    {
        try
        {
            // Get the list of methods of the class of obj
            Class objClass = obj.getClass();
            System.out.println("\n" + objClass.getName().substring(18));
	    System.out.println("------------------");
            Method[] allMethods = objClass.getMethods();

            // Iterate through the methods of the class and invoke
            // the methods which retrieve segment information
            for (int z = 0; z < allMethods.length; z++)
            {
                 // Get the name, return type of the method.
                String methodName = allMethods[z].getName();
                String retName = allMethods[z].getReturnType().getName();

                // Identify the methods which retrieve segment
                // information
                if ((methodName.startsWith("get"))
                        && (!methodName.equals("getSerializer"))
                        && (!methodName.equals("getDeserializer"))
                        && (!methodName.equals("getClass"))
                        && (!methodName.endsWith("timeAsDayString"))
                        && (!methodName.equals("getTypeDesc")))
                {
                    // Get an instance of the method from the
                    // class of obj.
                    Class[] paramClassArray = { };
                    Method getter =
                            objClass.getMethod(methodName, paramClassArray);
                    Object[] paramArray = {};

                    // Invoke the getter method
                    Object returnObject = getter.invoke(obj, paramArray);

                    // If the return type of the method is date/time,
                    // print it in the format specified using
                    // SimpleDateFormat.
                    if (retName.equals("java.util.Calendar"))
                    {
                        SimpleDateFormat sdf =
                                new SimpleDateFormat("MM-dd-yy hh:mm:ss.SS");
                        String sDateStr =
                                sdf.format(((Calendar)returnObject).getTime());
                        System.out.print(methodName + ": ");
                        System.out.print(sDateStr + "   ");
                    }
                    else
                    {
                        // Print the method name along with the values
                        // returned by executing it, if the return
                        // type is not date
                        System.out.print(methodName + ": ");
                        System.out.print(returnObject + "   ");
                    }
                } 
            }
        }
        catch (Exception ex)
        {
            System.err.println(ex.getMessage());
        }

        System.out.println("");
    }



    /*
     * Performs a Member search using MemName and MemDate rows.
     * This example does not take any parameters.
     */
    public static void main(String args[])
    {

	String domain = new String(args[0]);

        ex_esbMemSearchProvider memSearch = new ex_esbMemSearchProvider();

        Member[] members = null;
        try
        {
            // Perform the searchMember operation.
            members = memSearch.execute(domain);
        }
        catch(Exception e)
        {
            System.err.println(e.getMessage());
            e.printStackTrace();
        }

	int j=0;
        // Print the member information
        for (int i = 0; i < members.length; i++)
        {

	    // *** NOTE ***
	    // Providers only have data on the MPI_MEMHEAD, MPI_MEMNAME, MPI_MEMATTR, MPI_MEMIDENT, MPI_MEMDATE segments.

	    j = i + 1;
	    System.out.println("========================");
            System.out.println("= Member Record " + j + " of " + members.length + " =");
	    System.out.println("========================");

            // Get the member header information and
            // print it.
            MemHeadWs memHeadWs = members[i].getMemHead();
            memSearch.dumpObject(memHeadWs);

            // Get the member's name and print it.
            MemNameWs[] memNameWs = members[i].getMemName();
            memSearch.dumpArray(memNameWs);

            // Get the member's attributes  and print it.
            MemAttrWs[] memAttrWs = members[i].getMemAttr();
            memSearch.dumpArray(memAttrWs);

            // Get the member's SSN and print it.
            MemIdentWs[] memIdentWs = members[i].getMemIdent();
            memSearch.dumpArray(memIdentWs);

            // Get the member's birthdate information and print it.
            MemDateWs[] memDateWs = members[i].getMemDate();
            memSearch.dumpArray(memDateWs);

	    System.out.println("\n");
        }

	System.out.println("---------------------------------\n");
	System.out.println("TOTAL MEMBERS RETURNED: " + members.length);

        System.exit(0);
    }



}
