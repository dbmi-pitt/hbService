import java.util.Arrays;

public class Test
{
	public static void main(String args[])
	{
		PatientId test = new PatientId();
		test.setStudyId("123");
		String[] mpacIdarray = {"1", "2", "3", "4"};
		test.setMpacIds(mpacIdarray);
		test.setSrcIds(mpacIdarray);
		System.out.println(test.toString());

		if(Arrays.asList(mpacIdarray).contains("1"))
			System.out.println("found duplicate");
		else
			System.out.println("not in array");
	}
}