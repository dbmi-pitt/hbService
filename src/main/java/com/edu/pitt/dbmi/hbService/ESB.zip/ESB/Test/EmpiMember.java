package edu.pitt.dbmi.EmpiUtil;


import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.initiate.bean.ArrayOfMemAddrWs;
import com.initiate.bean.ArrayOfMemAttrWs;
import com.initiate.bean.ArrayOfMemDateWs;
import com.initiate.bean.ArrayOfMemNameWs;
import com.initiate.bean.ArrayOfMemIdentWs;
import com.initiate.bean.ArrayOfMemPhoneWs;
import com.initiate.bean.MemAddrWs;
import com.initiate.bean.MemAttrWs;
import com.initiate.bean.MemDateWs;
import com.initiate.bean.MemHeadWs;
import com.initiate.bean.MemNameWs;
import com.initiate.bean.MemIdentWs;
import com.initiate.bean.MemPhoneWs;
import com.initiate.bean.Member;

public class EmpiMember {
	@Autowired
	private static final Logger log = LoggerFactory.getLogger(EmpiMember.class);
	
	// Fields from memHead
	private	Long entRecNo;
	private	short matchScore;
	private	float matchCalc;
	private	List<String> srcCode;
	private	List<String> memIdNum;
	private String epicMrn;
	
	// Fields from memNameWs[0] in memName Array
	private	String nameCode;
	private	String onmFirst;
	private	String onmMiddle;
	private	String onmLast;
	private	String onmPrefix;
	private	String onmSuffix;
	private	String onmDegree;
	// Fields from the memAttrWs[0,1,2] in memAttr Array 
	private	String sex;
	private	String race;
	private	String empiId;
	private String mpacMrn;
	// Fields from memDateWs[0] in memDate Array
	private	String birthDt;
	// Fields from memIdentWs[0] in menIdent Array
	private	String ssn;
	// Fields from memPhoneWs[0,1] in memPhone Array
	private String phCode1;
	private String phNumber1;
	private String phCode2;
	private String phNumber2;
	// Fields from memAddrWs[0] in memAddr Array
	private String addrCode;
	private String city;
	private String state;
	private String stLine1;
	private String stLine2;
	private String stLine3;
	private String stLine4;
	private String zipCode;
	
	public EmpiMember() {
		super();
	}
	
	public EmpiMember(String sexVal, String raceVal, String empiIdVal, String birthDtVal,
			short matchScoreVal, float matchCalcVal, Long entRecNoVal, List<String> srcCodeVal,
			List<String> memIdNumVal, String ssnVal, String nameCodeVal, String onmFirstVal,
			String onmMiddleVal, String onmLastVal, String onmPrefixVal,
			String onmSuffixVal, String onmDegreeVal, String phCode1Val,
			String phNumber1Val, String phCode2Val, String phNumber2Val,
			String addrCodeVal, String cityVal, String stateVal, String stLine1Val,
			String stLine2Val, String stLine3Val, String stLine4Val, String zipCodeVal) {
		super();
		this.sex = sexVal;
		this.race = raceVal;
		this.empiId = empiIdVal;
		this.birthDt = birthDtVal;
		this.matchScore = matchScoreVal;
		this.matchCalc = matchCalcVal;
		this.entRecNo = entRecNoVal;
		this.srcCode = srcCodeVal;
		this.memIdNum = memIdNumVal;
		this.ssn = ssnVal;
		this.nameCode = nameCodeVal;
		this.onmFirst = onmFirstVal;
		this.onmMiddle = onmMiddleVal;
		this.onmLast = onmLastVal;
		this.onmPrefix = onmPrefixVal;
		this.onmSuffix = onmSuffixVal;
		this.onmDegree = onmDegreeVal;
		this.phCode1 = phCode1Val;
		this.phNumber1 = phNumber1Val;
		this.phCode2 = phCode2Val;
		this.phNumber2 = phNumber2Val;
		this.addrCode = addrCodeVal;
		this.city = cityVal;
		this.state = stateVal;
		this.stLine1 = stLine1Val;
		this.stLine2 = stLine2Val;
		this.stLine3 = stLine3Val;
		this.stLine4 = stLine4Val;
		this.zipCode = zipCodeVal;
	}
	
	static public Long getMemberEntRecNo(Member member) {
		// Get the memHead info from the Header
		MemHeadWs memHead = member.getMemHead();
		if (memHead == null) {
			log.error("memHead is null - skipping head info");
			return (long) 0;
		} else {
			return memHead.getEntRecno();
		}
	}
	
	static public String getMemberSrcCode(Member member) {
		// Get the memHead info from the Header
		MemHeadWs memHead = member.getMemHead();
		if (memHead == null) {
			log.error("memHead is null - skipping head info");
			return "";
		} else {
			return memHead.getSrcCode() + ":" + memHead.getMemIdnum();
		}
	}
	
	/*
	 * The EMPI Service will return multiple records from multiple sources, with
	 * each record containing the most current "unique" information from each of 
	 * those sources and they need to be "merged" together to create the "Entity Most Current
	 * Attribute"'s for that entity Record.  This depends upon settings made during the 
	 * request.  If the "getType" is set to ASENTITY => request.setGetType("ASENTITY")
     * and the composite view to entity most current attribute => request.setCvwName("EMCA");
     * then the service responds that way.  Each source should only be merged in one time
	 */
	
	public int copyFromMember(Member member) {
		int retVal = 1;

		// Get the memHead info from the Header
		MemHeadWs memHead = member.getMemHead();
		if (memHead == null) {
			log.error("memHead is null - skipping member record - head can't be null");
			return 0;
		} else if (this.checkSource(memHead.getSrcCode(), memHead.getMemIdnum()) == false){
			// Have not merged source yet, get the head info from this source
			if(memHead.getMatchScore() > this.getMatchScore())
				this.setMatchScore(memHead.getMatchScore());
			float matchCalc = this.getMatchScore();
			matchCalc /= 10.0;
			this.setMatchCalc(matchCalc);
			this.setEntRecNo(memHead.getEntRecno());
			this.addSource(memHead.getSrcCode(), memHead.getMemIdnum());
			// The "MemIdnum for EPIC is also the MRN, store it if this is first EPIC source
			if ((memHead.getSrcCode().equals("EPIC")) && (this.epicMrn == null)) {
				this.setEpicMrn(memHead.getMemIdnum());
			}
		} else {
			log.info("Already merged Source " + memHead.getSrcCode() + ":" + memHead.getMemIdnum() 
					+ " into empiMember");
			return 1;
		}
		// Get the Name info from memNameWs[0]
		ArrayOfMemNameWs memNameArr = member.getMemName();
		if (memNameArr == null) {
			log.trace("memNameArr is null = skipping member name record");
			retVal = 0;
		} else {
			MemNameWs memName = memNameArr.getItem().get(0);
			if (memName == null) {
				log.error("memNameWs[0] is null = skipping member record");
				retVal = 0;
			} else {
				this.setNameCode(memName.getAttrCode());
				assert(this.getNameCode().equals("LGLNAME"));
				this.setOnmLast(memName.getOnmLast());
				this.setOnmFirst(memName.getOnmFirst());
				this.setOnmMiddle(memName.getOnmMiddle());
				this.setOnmPrefix(memName.getOnmPrefix());
				this.setOnmSuffix(memName.getOnmSuffix());
				this.setOnmDegree(memName.getOnmDegree());
			}
			if (memNameArr.getItem().size() > 1) {
				memName = memNameArr.getItem().get(1);
				log.info("Extra Member Name Attr: " + memName.getAttrCode());
			}
		}			
		// Get the Attributes from memAttrArr
		ArrayOfMemAttrWs memAttrArr = member.getMemAttr();
		if (memAttrArr == null) {
			log.trace("memAttrArr is null = skipping member attrbutes");
		} else {
			List<MemAttrWs> memAttrList = memAttrArr.getItem();
			if (memAttrList.isEmpty()) {
				log.error("memAttrArr is empty = skipping member attrbutes");
				retVal = 0;
			} else {
				for (MemAttrWs memAttr: memAttrList) {
					if (memAttr == null) {
						log.error("memAttr is null = skipping member record");
						retVal = 0;
					}else{
						String attrCode = memAttr.getAttrCode();
						if (attrCode.equals("SEX")) {
							this.setSex(memAttr.getAttrVal());
						} else if (attrCode.equals("RACE")) {
							this.setRace(memAttr.getAttrVal());
						} else if (attrCode.equals("EMPIID")) {
							this.setEmpiId(memAttr.getAttrVal());
						} else if (attrCode.equals("MPACMRN")) {
							this.setMpacMrn(memAttr.getAttrVal());
						} else {
							log.info("Unknown Member Attribute: " + attrCode + 
								 " Value: " + memAttr.getAttrVal());
						}
					}
				}
			}
		}			
		// Fields from memDateWs[0] in memDate Array
		ArrayOfMemDateWs memDateArr = member.getMemDate();
		if (memDateArr == null) {
			log.trace("memDateArr is null = skipping member Date record");
		} else {
			MemDateWs memDate = memDateArr.getItem().get(0);
			if (memDate == null) {
				log.error("memDateWs[0] is null = skipping member date record");
				retVal = 0;
			} else {
				if (memDate.getAttrCode().equals("BIRTHDT")) {
					this.setBirthDt(memDate.getDateVal());
				} else {
					log.info("Unknown Member Date Value: " + memDate.getAttrName() + 
						 " Value: " + memDate.getDateVal());
					retVal = 0;
				}
			}
		}
		// Fields from memIdentWs[0] in menIdent Array
		ArrayOfMemIdentWs memIdentArr = member.getMemIdent();
		if (memIdentArr == null) {
			log.trace("memIdentArr is null = skipping member Ident record");
		} else {
			MemIdentWs memIdent = memIdentArr.getItem().get(0);
			if (memIdent == null) {
				log.error("memIdentWs[0] is null = skipping member Ident record");
				retVal = 0;
			} else {
				if ((memIdent.getAttrCode().equals("SSN")) && 
					(memIdent.getIdIssuer().equals("SSA"))) {
					this.setSsn(memIdent.getIdNumber());
				} else {
					log.info("Unknown Member Ident Code: " + memIdent.getAttrCode() + 
						 " Issurer: " + memIdent.getIdIssuer() +
						 " Value: " + memIdent.getIdNumber());
				}
			}
			if (memIdentArr.getItem().size() > 1) {
				memIdent = memIdentArr.getItem().get(1);
				log.info("Extra Member Ident Code: " + memIdent.getAttrCode() + 
						 " Issurer: " + memIdent.getIdIssuer() +
						 " Value: " + memIdent.getIdNumber());
			}
		}
		// Fields from memPhoneWs[0,1] in memPhone Array
		ArrayOfMemPhoneWs memPhoneArr = member.getMemPhone();
		if (memPhoneArr == null) {
			log.trace("memPhoneArr is null = skipping member phone record");
		} else {
			MemPhoneWs memPhone = memPhoneArr.getItem().get(0);
			if (memPhone == null) {
				log.error("memPhoneWs[0] is null = skipping member phone record");
				retVal = 0;
			} else {
				this.setPhCode1(memPhone.getAttrCode());
				this.setPhNumber1(memPhone.getPhNumber());
				if (memPhoneArr.getItem().size() >= 2) {
					memPhone = memPhoneArr.getItem().get(1);
					if (memPhone == null) {
						log.error("memPhoneWs[1] is null = skipping member phone record");
						retVal = 0;
					} else {
						this.setPhCode2(memPhone.getAttrCode());
						this.setPhNumber2(memPhone.getPhNumber());
					}
				}
				if (memPhoneArr.getItem().size() > 2) {
					memPhone = memPhoneArr.getItem().get(2);
					log.info("Extra Member Phone Attr: " + memPhone.getAttrCode());
				}
			}
		}
		// Fields from memAddrWs[0] in memAddr Array
		ArrayOfMemAddrWs memAddrArr = member.getMemAddr();
		if (memAddrArr == null) {
			log.trace("memAddrArr is null = skipping member address record");
		} else {
			MemAddrWs memAddr = memAddrArr.getItem().get(0);
			if (memAddr == null) {
				log.error("memAddrWs[0] is null = skipping member address record");
				retVal = 0;
			} else {
				this.setAddrCode(memAddr.getAttrCode());
				assert(this.getAddrCode().equals("HOMEADDR"));
				this.setCity(memAddr.getCity());
				this.setState(memAddr.getState());
				this.setStLine1(memAddr.getStLine1());
				this.setStLine2(memAddr.getStLine2());
				this.setStLine3(memAddr.getStLine3());
				this.setStLine4(memAddr.getStLine4());
				this.setZipCode(memAddr.getZipCode());

				if (memAddrArr.getItem().size() > 1) {
					memAddr = memAddrArr.getItem().get(1);
					log.info("Extra Member Address Attr: " + memAddr.getAttrCode());
				}
			}
		}
		return retVal;
	}
	
	public String getSex() {
		return this.sex;
	}
	
	public String getFmtSex() {
		if (this.sex == null) {
			return this.sex;
		} else if (this.sex.equals("F")) {
			return "F-Female";
		} else if (this.sex.equals("M")) {
			return "M-Male";
		} else {
			return "U-Unknown";
		}
	}
	
	public void setSex(String sexVal) {
		this.sex = sexVal;
	}
	public String getRace() {
		return this.race;
	}
	public void setRace(String raceVal) {
		this.race = raceVal;
	}
	public String getEmpiId() {
		return this.empiId;
	}
	public void setEmpiId(String empiIdVal) {
		this.empiId = empiIdVal;
	}
	public String getMpacMrn() {
		return this.mpacMrn;
	}

	public void setMpacMrn(String mpacMrnVal) {
		this.mpacMrn = mpacMrnVal;
	}
	public String getBirthDt() {
		return this.birthDt;
	}
	public void setBirthDt(String birthDtVal) {
		this.birthDt = birthDtVal;
	}
	
	public Date getDob() {
		Date Dob = null;
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
        if(this.birthDt != null){
			try {
				Dob = format.parse(this.birthDt);
			} catch (ParseException e1) {
				e1.printStackTrace();
			}
        }
		return Dob;
	}
	
	public short getMatchScore() {
		return this.matchScore;
	}
	public void setMatchScore(short matchScoreVal) {
		this.matchScore = matchScoreVal;
	}
	public float getMatchCalc() {
		return this.matchCalc;
	}
	public void setMatchCalc(float matchCalcVal) {
		this.matchCalc = matchCalcVal;
	}
	public Long getEntRecNo() {
		return this.entRecNo;
	}
	public void setEntRecNo(long entRecNoVal) {
		this.entRecNo = entRecNoVal;
	}
	public List<String> getSrcCode() {
		return this.srcCode;
	}
	public void setSrcCode(List<String> srcCodeVal) {
		this.srcCode = srcCodeVal;
	}

	private void addSource(String srcCodeVal, String memIdNumVal) {
		if ((this.srcCode == null) && (this.memIdNum == null)){
			this.srcCode = new ArrayList<String>();
			this.memIdNum = new ArrayList<String>();
		}
		assert(this.srcCode.size() == this.memIdNum.size()); // are lists in sync?
		this.srcCode.add(srcCodeVal);
		this.memIdNum.add(memIdNumVal);
	}

	private boolean checkSource(String srcCodeVal, String memIdNumVal) {
		if ((this.srcCode != null) && (this.memIdNum != null)) {
			assert(this.srcCode.size() == this.memIdNum.size()); // are lists in sync?
			if ((this.srcCode.contains(srcCodeVal) == true) &&
				(this.memIdNum.contains(memIdNumVal) == true)) {
				return true;
			}
		}
		return false;
	}

	public String getSourceFromMember(Member member) {
		// Get the memHead info from the Header
		MemHeadWs memHead = member.getMemHead();
		if (memHead == null) {
			log.error("memHead is null - skipping member record - head can't be null");
			return "";
		}
		String source = memHead.getSrcCode() + ":" + memHead.getMemIdnum();
		return source;
	}
	
	public String getSource(int index) {
		assert(this.srcCode.size() == this.memIdNum.size());
		if ((this.srcCode.size() == 0) && (this.memIdNum.size() == 0)) {
			return null;
		} else {
			String source = this.srcCode.get(index) + ":"  + this.memIdNum.get(index);
			return source;
		}
	}
	
	public int getNumSources() {
		if (this.srcCode == null) {
			assert(this.srcCode == this.memIdNum);
			return 0;
		} else {
			assert(this.srcCode.size() == this.memIdNum.size()); // are lists in sync?
			return this.srcCode.size();
		}
	}
	
	public List<String> getMemIdNum() {
		return this.memIdNum;
	}
	public void setMemIdNum(List<String> memIdNumVal) {
		this.memIdNum = memIdNumVal;
	}
	
	public String getSsn() {
		return this.ssn;
	}
	
	public String getFmtSsn() {
		if ((this.ssn != null) && (this.ssn.length() == 9)) {
			StringBuilder fmtSsn = new StringBuilder(this.ssn);
			fmtSsn.insert(3, '-');
			fmtSsn.insert(6, '-');
			return fmtSsn.toString();
		} else {
			return this.ssn;
		}
	}
	public void setSsn(String ssnVal) {
		this.ssn = ssnVal;
	}
	public String getNameCode() {
		return this.nameCode;
	}
	public void setNameCode(String nameCodeVal) {
		this.nameCode = nameCodeVal;
	}
	public String getOnmFirst() {
		return this.onmFirst;
	}
	public void setOnmFirst(String onmFirstVal) {
		this.onmFirst = onmFirstVal;
	}
	public String getOnmMiddle() {
		return this.onmMiddle;
	}
	public void setOnmMiddle(String onmMiddleVal) {
		this.onmMiddle = onmMiddleVal;
	}
	public String getOnmLast() {
		return this.onmLast;
	}
	public void setOnmLast(String onmLastVal) {
		this.onmLast = onmLastVal;
	}
	public String getOnmPrefix() {
		return this.onmPrefix;
	}
	public void setOnmPrefix(String onmPrefixVal) {
		this.onmPrefix = onmPrefixVal;
	}
	public String getOnmSuffix() {
		return this.onmSuffix;
	}
	public void setOnmSuffix(String onmSuffixVal) {
		this.onmSuffix = onmSuffixVal;
	}
	public String getOnmDegree() {
		return this.onmDegree;
	}
	public void setOnmDegree(String onmDegreeVal) {
		this.onmDegree = onmDegreeVal;
	}
	
	public String getDisplayName() {
		StringBuilder memDisplayName = new StringBuilder();
		memDisplayName.append(this.getOnmFirst());
		memDisplayName.append(' ');
		if (!this.getOnmMiddle().isEmpty()) {
			memDisplayName.append(this.getOnmMiddle());
			memDisplayName.append(' ');
		}
		memDisplayName.append(this.getOnmLast());
		return memDisplayName.toString();
	}
	
	public String getPhCode1() {
		return this.phCode1;
	}
	public void setPhCode1(String phCode1Val) {
		this.phCode1 = phCode1Val;
	}
	public String getPhNumber1() {
		return this.phNumber1;
	}
	public void setPhNumber1(String phNumber1Val) {
		this.phNumber1 = phNumber1Val;
	}
	public String getPhCode2() {
		return this.phCode2;
	}
	public void setPhCode2(String phCode2Val) {
		this.phCode2 = phCode2Val;
	}
	public String getPhNumber2() {
		return this.phNumber2;
	}
	public void setPhNumber2(String phNumber2Val) {
		this.phNumber2 = phNumber2Val;
	}
	public String getAddrCode() {
		return this.addrCode;
	}
	public void setAddrCode(String addrCodeVal) {
		this.addrCode = addrCodeVal;
	}
	public String getCity() {
		return this.city;
	}
	public void setCity(String cityVal) {
		this.city = cityVal;
	}
	public String getState() {
		return this.state;
	}
	public void setState(String stateVal) {
		this.state = stateVal;
	}
	public String getStLine1() {
		return this.stLine1;
	}
	public void setStLine1(String stLine1Val) {
		this.stLine1 = stLine1Val;
	}
	public String getStLine2() {
		return this.stLine2;
	}
	public void setStLine2(String stLine2Val) {
		this.stLine2 = stLine2Val;
	}
	public String getStLine3() {
		return this.stLine3;
	}
	public void setStLine3(String stLine3Val) {
		this.stLine3 = stLine3Val;
	}
	public String getStLine4() {
		return this.stLine4;
	}
	public void setStLine4(String stLine4Val) {
		this.stLine4 = stLine4Val;
	}
	public String getZipCode() {
		return this.zipCode;
	}
	public void setZipCode(String zipCodeVal) {
		this.zipCode = zipCodeVal;
	}

	public String getEpicMrn() {
		return this.epicMrn;
	}

	public void setEpicMrn(String epicMrnVal) {
		this.epicMrn = epicMrnVal;
	}
}
