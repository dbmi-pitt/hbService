/*----------------------------------------------------------------------*/
/*  Copyright (c) 2004 by Initiate Systems, Inc. (INITIATE)             */
/*                         All Rights Reserved.                         */
/*         THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF INITIATE.     */
/*         The copyright notice above does not evidence any             */
/*         actual or intended publication of such source code.          */
/*----------------------------------------------------------------------*/

package initiatews.example;

/**
 * <p>Title: Web Service Client</p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Initiate Systems, Inc.</p>
 * @author not attributable
 * @version 1.0
 */

import com.initiate.bean.*;
import edu.upmc.www.esdm.empi.service.*;
import esdm.edu.upmc.www.empi.service.*;

import java.beans.*;
import java.lang.reflect.Method;
import java.text.SimpleDateFormat;
import java.util.Calendar;

/*
 * This example illustrates the use of the getMember operation which
 * can be used to get member information.
 */
public class ex_esbMemGet
{
    String m_sSegCodeFilter = "MEMHEAD,MEMATTRALL";

    // Member Id and Source code of the member.
    String m_sSrcCode       = "MEDIPAC";  
    String m_sMemIdnum      = "123456";

    /**
     * This method gets the Member data from the Member table
     * based on the segment codes, source code and member Id.
     *
     * @param sSegCodeFilter segment code filter
     * @param sSrcCode source code
     * @param sMemIdnum member Id
     *
     * @param Member[] member information
     *
     *  Used by other examples to verify they worked properly.
     *
     */
    public Member[] execute(String sSegCodeFilter,
                            String sSrcCode,
                            String sMemIdnum)
    {
        //setup defaults
        if ( (sSegCodeFilter != null) && (sSegCodeFilter.length() > 0) )
        {
            m_sSegCodeFilter = sSegCodeFilter;
        }
        if ( (sSrcCode != null) && (sSrcCode.length() > 0) )
        {
            m_sSrcCode = sSrcCode;
        }
        if ( (sMemIdnum != null) && (sMemIdnum.length() > 0) )
        {
            m_sMemIdnum = sMemIdnum;
        }

        //get service and port to use
        WSExport1_IEMPIServiceHttpService service;
        IEMPIService    port = null;
        try
        {
            // Create an IdentityHubServiceLocator object.
            // The IdentityHubServiceLocator is the starting point
            // for accessing the services.
            service = new WSExport1_IEMPIServiceHttpServiceLocator();

            // Create an IdentityHubPort object.
            // The IdentityHubPort provides support for the
            // dynamic invocation of a service endpoint.
            port    = service.getWSExport1_IEMPIServiceHttpPort();

            // Create a request object using which we pass input
            // parameters to the operation.
            MemberGetRequest request = new MemberGetRequest();

            // Setup the SrcCode:MemIdnum key used for the get
            request.setSrcCode(m_sSrcCode);
            request.setMemIdnum(m_sMemIdnum);

            // Set a segment code filter to limit
            // output to specific segments.
            request.setSegCodeFilter(m_sSegCodeFilter);

            // Set username & password to authenticate as
            request.setUserName("yourUserName");
            request.setUserPassword("yourPassword");
         
            // Set entity type as Identity (id).
            // Entity types are listed in mpi_enttype table.
            request.setEntType("id"); 

            // Setup Member Type of Member 
            // Member types are listed in mpi_memtype table.
            request.setMemType("PERSON");

            // Setup Get Type ASENTITY to get all
            // linked members with this member
            request.setGetType("ASENTITY");

            // Sets the sort order of the Members
            // You can specify a sort based on the MemHead values
	    request.setKeySortOrder("-getMatchScore,-getEntRecno");

            // Perform the getMember operation.
            Member[] members = port.getMember(request);
            return members;

        }
        catch(Exception e)
        {
            System.err.println(e.getMessage());
            e.printStackTrace();

        }

        return null;
    }


    /**
     * This method prints an array of objects representing the
     * Initiate Web Services types using the dumpObject method.
     *
     * @param obj the object array
     */
    public void dumpArray(Object[] obj)
    {
        if (obj == null)
        {
            return;
        }

        // Iterate through the object array and print each object.
        for (int k = 0; k < obj.length; k++)
        {
            dumpObject(obj[k]);
        }
    }

    /**
     * This method prints the data contained in an object
     * representing a Initiate Web Services type.
     *
     * @param obj the object
     */
    public void dumpObject(Object obj)
    {
        try
        {
            // Get the list of methods of the class of obj
            Class objClass = obj.getClass();
            System.out.print(objClass.getName().substring(18) + ".");
            Method[] allMethods = objClass.getMethods();

            // Iterate through the methods of the class and invoke
            // the methods which retrieve segment information
            for (int z = 0; z < allMethods.length; z++)
            {
                 // Get the name, return type of the method.
                String methodName = allMethods[z].getName();
                String retName = allMethods[z].getReturnType().getName();

                // Identify the methods which retrieve segment
                // information
                if ((methodName.startsWith("get"))
                        && (!methodName.equals("getSerializer"))
                        && (!methodName.equals("getDeserializer"))
                        && (!methodName.equals("getClass"))
                        && (!methodName.endsWith("timeAsDayString"))
                        && (!methodName.equals("getTypeDesc")))
                {
                    // Get an instance of the method from the
                    // class of obj.
                    Class[] paramClassArray = { };
                    Method getter =
                            objClass.getMethod(methodName, paramClassArray);
                    Object[] paramArray = {};

                    // Invoke the getter method
                    Object returnObject = getter.invoke(obj, paramArray);

                    // If the return type of the method is date/time,
                    // print it in the format specified using
                    // SimpleDateFormat.
                    if (retName.equals("java.util.Calendar"))
                    {
                        SimpleDateFormat sdf =
                                new SimpleDateFormat("MM-dd-yy hh:mm:ss.SS");
                        String sDateStr =
                                sdf.format(((Calendar)returnObject).getTime());
                        System.out.print("" + methodName + ":");
                        System.out.print(sDateStr + "  ");
                    }
                    else
                    {
                        // Print the method name along with the values
                        // returned by executing it, if the return
                        // type is not date
                        System.out.print("" + methodName + ":");
                        System.out.print(returnObject + "  ");
                    }
                }
            }
        }
        catch (Exception ex)
        {
            System.err.println(ex.getMessage());
        }

        System.out.println("");
    }


    /**
     * This method is the entry point for executing this class and
     * calls the doGetMember method.
     *
     *  Arg[0] SrcCodeFilter to use 
     *  Arg[1] SrcCode
     *  Arg[2] MemIdnum
     *
     */
    public static void main(String args[])
    {
        Member[] members;
        ex_esbMemGet memGet = new ex_esbMemGet();

        // Get member information.
        // If the user passes insufficient number of arguments then
        // ArrayIndexOutOfBoundsException is thrown
        try
        {
            //arg[0] SegCodeFilter
            //arg[1] SrcCode
            //arg[2] MemIdnum
            members = memGet.execute(args[0],
                                     args[1],
                                     args[2]);
        }
        catch(ArrayIndexOutOfBoundsException e)
        {
            // If no arguments are passed then take default values.
            members = memGet.execute(null, null, null);
        }

        // Print the member information.
        for (int i = 0; i < members.length; i++)
        {
            System.out.println("*** Member Start ****");
            MemHeadWs memHeadWs = members[i].getMemHead();
            memGet.dumpObject(memHeadWs);

            MemNameWs[] memNameWs = members[i].getMemName();
            memGet.dumpArray(memNameWs);
	    
	    MemIdentWs[] memIdentWs = members[i].getMemIdent();
	    memGet.dumpArray(memIdentWs);

            MemAddrWs[] memAddrWs = members[i].getMemAddr();
            memGet.dumpArray(memAddrWs);

            MemPhoneWs[] memPhoneWs = members[i].getMemPhone();
            memGet.dumpArray(memPhoneWs);

            MemDateWs[] memDateWs = members[i].getMemDate();
            memGet.dumpArray(memDateWs);

            MemAttrWs[] memAttrWs = members[i].getMemAttr();
            memGet.dumpArray(memAttrWs);

            MemXtskWs[] memXtskWs = members[i].getMemXtsk();
            memGet.dumpArray(memXtskWs);

	    EntXtskWs[] entXtskWs = members[i].getEntXtsk();
            memGet.dumpArray(entXtskWs);

        }

        System.exit(0);
    }

}
